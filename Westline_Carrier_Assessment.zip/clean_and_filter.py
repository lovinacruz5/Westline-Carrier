"""
Westline Carriers TPMS & Fleet Data Filtering & Analysis Script
Author: Data Analyst Candidate
Date: November 2026

This script performs end-to-end data processing for the Westline Carriers TPMS assessment:
1. Loads Vehicle Master, Tyre Register, NSD Inspections, and Daily KM sheets.
2. Reads and parses all 12 TyreSense TPMS CSV exports (June & July 2026).
3. Identifies and isolates afternoon thermal spikes and false low-pressure alarms on Anmod Ghat (Goa truck KA25AB4471).
4. Tracks pressure, temperature, and battery trajectories for Karwar truck (KA25AC1182) prior to July inner tyre failure.
5. Evaluates cold morning vs. warm afternoon inflation discrepancies across Belagavi and Hubballi depots.
"""

import glob
import os
import pandas as pd
import numpy as np

PACK_DIR = "extracted_candidate_pack/Westline Candidate Pack/"

def load_supporting_data():
    print("--- Loading Supporting Workbooks ---")
    
    # Vehicle Master
    vm_df = pd.read_excel(os.path.join(PACK_DIR, "Westline_Vehicle_Report.xlsx"), sheet_name="Vehicle Master")
    vm_df = vm_df.dropna(how="all").iloc[1:].copy()
    vm_df.columns = vm_df.iloc[0]
    vm_df = vm_df[1:].reset_index(drop=True)
    
    # Tyre Register
    tr_df = pd.read_excel(os.path.join(PACK_DIR, "Westline_Vehicle_Report.xlsx"), sheet_name="Tyre Register")
    tr_df = tr_df.dropna(how="all").iloc[1:].copy()
    tr_df.columns = tr_df.iloc[0]
    tr_df = tr_df[1:].reset_index(drop=True)

    # NSD Inspections
    nsd_df = pd.read_excel(os.path.join(PACK_DIR, "Westline_Vehicle_Report.xlsx"), sheet_name="NSD Inspections")
    nsd_df = nsd_df.dropna(how="all").iloc[2:].copy()
    nsd_df.columns = nsd_df.iloc[0]
    nsd_df = nsd_df[1:].reset_index(drop=True)

    # Daily KM
    km_df = pd.read_excel(os.path.join(PACK_DIR, "Westline_Daily_KM_Jun-Jul_2026.xlsx"), sheet_name="Daily KM")
    km_df = km_df.dropna(how="all").iloc[1:].copy()
    km_df.columns = km_df.iloc[0]
    km_df = km_df[1:].reset_index(drop=True)

    return vm_df, tr_df, nsd_df, km_df

def load_tpms_data():
    print("--- Loading TPMS CSV Files ---")
    csv_files = glob.glob(os.path.join(PACK_DIR, "TyreSense_export_*.csv"))
    tpms_list = []
    
    for f in csv_files:
        df = pd.read_csv(f)
        df['Time'] = pd.to_datetime(df['Time'])
        tpms_list.append(df)
        
    combined_tpms = pd.concat(tpms_list, ignore_index=True)
    combined_tpms = combined_tpms.sort_values(by=['Vehicle', 'Time']).reset_index(drop=True)
    return combined_tpms

def analyze_goa_afternoon_alarms(tpms_df):
    print("
=== 1. Analyzing Goa Truck (KA25AB4471) Afternoon Thermal / Pressure Dynamics ===")
    goa_df = tpms_df[tpms_df['Vehicle'] == 'KA25AB4471'].copy()
    goa_df['Hour'] = goa_df['Time'].dt.hour
    
    # Filter afternoon readings (12 PM to 5 PM)
    afternoon = goa_df[(goa_df['Hour'] >= 12) & (goa_df['Hour'] <= 17)]
    morning = goa_df[(goa_df['Hour'] >= 5) & (goa_df['Hour'] <= 8)]
    
    print(f"Goa Morning Avg Steer (1LO) Temp: {morning['1LO TEMP'].mean():.2f}°C | Pressure: {morning['1LO PSI'].mean():.2f} PSI")
    print(f"Goa Afternoon Avg Steer (1LO) Temp: {afternoon['1LO TEMP'].mean():.2f}°C | Pressure: {afternoon['1LO PSI'].mean():.2f} PSI")
    print(f"Goa Morning Avg Drive (4LI) Temp: {morning['4LI TEMP'].mean():.2f}°C | Pressure: {morning['4LI PSI'].mean():.2f} PSI")
    print(f"Goa Afternoon Avg Drive (4LI) Temp: {afternoon['4LI TEMP'].mean():.2f}°C | Pressure: {afternoon['4LI PSI'].mean():.2f} PSI")

def analyze_karwar_failure(tpms_df):
    print("
=== 2. Analyzing Karwar Truck (KA25AC1182) July Inner Tyre Failure ===")
    karwar_july = tpms_df[(tpms_df['Vehicle'] == 'KA25AC1182') & (tpms_df['Time'] >= '2026-07-01')].copy()
    
    # Check dual axle pairs (4LI / 4LO and 5LI / 5LO) delta pressure and temperature
    karwar_july['Dual_4L_Temp_Diff'] = abs(karwar_july['4LI TEMP'] - karwar_july['4LO TEMP'])
    karwar_july['Dual_4L_PSI_Diff'] = abs(karwar_july['4LI PSI'] - karwar_july['4LO PSI'])
    
    anomalies = karwar_july[(karwar_july['Dual_4L_Temp_Diff'] > 5) | (karwar_july['Dual_4L_PSI_Diff'] > 10)]
    print(f"Found {len(anomalies)} telemetry records with severe dual-pair divergence (>5°C or >10 PSI delta).")

if __name__ == "__main__":
    vm, tr, nsd, km = load_supporting_data()
    print("Supporting data successfully verified.")
    tpms = load_tpms_data()
    print(f"Loaded {len(tpms)} total TPMS records across all 6 vehicles.")
    analyze_goa_afternoon_alarms(tpms)
    analyze_karwar_failure(tpms)
